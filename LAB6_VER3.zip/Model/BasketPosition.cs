﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class BasketPosition
    {
        public int ProductID { get; set; }
        public Product Product { get; set; }
        public int UserID { get; set; }
#pragma warning disable CS8618 // Pole niedopuszczające wartości null musi zawierać wartość inną niż null podczas kończenia działania konstruktora. Rozważ zadeklarowanie pola jako dopuszczającego wartość null.
        public User User { get; set; }
#pragma warning restore CS8618 // Pole niedopuszczające wartości null musi zawierać wartość inną niż null podczas kończenia działania konstruktora. Rozważ zadeklarowanie pola jako dopuszczającego wartość null.
        public int Amount { get; set; }
    }
}
