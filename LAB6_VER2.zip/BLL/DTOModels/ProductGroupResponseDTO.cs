﻿namespace BLL.DTOModels
{
    public record ProductGroupResponseDTO(int ID, string Name, bool HasSubGroups);

}
