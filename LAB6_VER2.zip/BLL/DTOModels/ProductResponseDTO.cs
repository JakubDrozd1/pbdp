﻿namespace BLL.DTOModels
{
    public record ProductResponseDTO(int ID, string Name, double Price, string GroupName);
}
