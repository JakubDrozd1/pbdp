﻿using BLL.DTOModels;

namespace BLL.ServiceInterfaces
{
    public interface IProductService
    {
        IEnumerable<ProductResponseDTO> GetProducts(string? sortBy, bool? descending, string? nameFilter, string? groupNameFilter, int? groupId, bool? includeInactive);
        void AddProduct(ProductRequestDTO productDto);
        void DeactivateProduct(int productId);
        void ActivateProduct(int productId);
        void DeleteProduct(int productId);
        void AddProductGroup(ProductGroupRequestDTO productGroupDto);
        public IEnumerable<ProductGroupResponseDTO> GetProductGroups(int? parentID, bool ascending);
    }
}
