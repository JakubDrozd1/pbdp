﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Microsoft.EntityFrameworkCore;
using Model;

namespace BLL_EF
{
    public class ProductService(WebstoreContext _webstoreContext) : IProductService
    {
        private WebstoreContext webstoreContext = _webstoreContext;

        public void ActivateProduct(int productId)
        {
            var product = webstoreContext.Products.Find(productId);
            if (product == null) return;
            product.IsActive = true;
            webstoreContext.SaveChanges();
        }

        public void AddProduct(ProductRequestDTO productDto)
        {
            var product = new Product()
            {
                Name = productDto.Name,
                Price = productDto.Price,
                GroupID = productDto.GroupID,
                IsActive = true
            };
            webstoreContext.Products.Add(product);
            webstoreContext.SaveChanges();
        }

        public void AddProductGroup(ProductGroupRequestDTO productGroupDto)
        {
            webstoreContext.ProductGroups.Add(new ProductGroup { Name = productGroupDto.Name, ParentID = productGroupDto.ParentID });
            webstoreContext.SaveChanges();
        }

        public void DeactivateProduct(int productId)
        {
            var product = webstoreContext.Products.Find(productId);
            if (product == null) return;
            product.IsActive = false;
            webstoreContext.SaveChanges();
        }

        public void DeleteProduct(int productId)
        {
            var product = webstoreContext.Products.Find(productId);
            if (product == null) return;
            webstoreContext.Products.Remove(product);
            webstoreContext.SaveChanges();
        }

        public IEnumerable<ProductGroupResponseDTO> GetProductGroups(int? parentID, bool ascending)
        {
            var query = webstoreContext.ProductGroups.AsQueryable();

            query = query.Where(pg => pg.ParentID == parentID);

            query = ascending ? query.OrderBy(pg => pg.Name) : query.OrderByDescending(pg => pg.Name);

            return query.Select(pg => new ProductGroupResponseDTO(pg.ID, pg.Name, webstoreContext.ProductGroups.Any(g => g.ParentID == pg.ID))).ToList();
        }


        public IEnumerable<ProductResponseDTO> GetProducts(string? sortBy, bool? descending, string? nameFilter, string? groupNameFilter, int? groupId, bool? includeInactive)
        {
            var query = webstoreContext.Products.Include(p => p.Group).AsQueryable();

            if (!includeInactive ?? false)
                query = query.Where(p => p.IsActive);

            if (!string.IsNullOrEmpty(nameFilter))
                query = query.Where(p => p.Name.Contains(nameFilter));

            if (!string.IsNullOrEmpty(groupNameFilter))
                query = query.Where(p => p.GroupID != null && p.Group.Name.Contains(groupNameFilter));
            if (groupId >= 0)
                query = query.Where(p => p.GroupID == groupId);

            if (sortBy == "Name")
            {
                query = descending ?? false ? query.OrderByDescending(p => p.Name) : query.OrderBy(p => p.Name);
            }
            else if (sortBy == "Price")
            {
                query = descending ?? false ? query.OrderByDescending(p => p.Price) : query.OrderBy(p => p.Price);
            }
            else if (sortBy == "GroupName")
            {
                query = descending ?? false ? query.OrderByDescending(p => p.Group.Name) : query.OrderBy(p => p.Group.Name);
            }

            var products = query.ToList();
            return products.Select(p => new ProductResponseDTO(p.ID, p.Name, p.Price, GetRoot(p.Group))).ToList();
        }

        private string GetRoot(ProductGroup group)
        {
            var rootPath = new List<string>();

            while (group != null)
            {
                rootPath.Insert(0, group.Name);
                group = webstoreContext.ProductGroups.Find(group.ParentID);
            }

            return string.Join("/", rootPath);
        }
    }
}
