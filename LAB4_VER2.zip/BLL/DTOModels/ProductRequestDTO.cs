﻿namespace BLL.DTOModels
{
    public record ProductRequestDTO(string Name, double Price, int GroupID);
}
