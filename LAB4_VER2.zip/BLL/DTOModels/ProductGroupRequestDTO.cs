﻿namespace BLL.DTOModels
{
    public record ProductGroupRequestDTO(string Name, int? ParentID);

}
