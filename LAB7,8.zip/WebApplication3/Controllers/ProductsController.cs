﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace WebstoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpPost("add")]
        public IActionResult AddProduct([FromBody] ProductRequestDTO productDto)
        {
            if (productDto == null)
            {
                return BadRequest("Invalid product data.");
            }

            _productService.AddProduct(productDto);
            return Ok("Product added successfully.");
        }

        [HttpPost("group/add")]
        public IActionResult AddProductGroup([FromBody] ProductGroupRequestDTO productGroupDto)
        {
            if (productGroupDto == null)
            {
                return BadRequest("Invalid product group data.");
            }

            _productService.AddProductGroup(productGroupDto);
            return Ok("Product group added successfully.");
        }

        [HttpPut("activate/{productId}")]
        public IActionResult ActivateProduct(int productId)
        {
            _productService.ActivateProduct(productId);
            return Ok("Product activated.");
        }

        [HttpPut("deactivate/{productId}")]
        public IActionResult DeactivateProduct(int productId)
        {
            _productService.DeactivateProduct(productId);
            return Ok("Product deactivated.");
        }

        [HttpDelete("delete/{productId}")]
        public IActionResult DeleteProduct(int productId)
        {
            _productService.DeleteProduct(productId);
            return Ok("Product deleted.");
        }

        [HttpGet("groups")]
        public IActionResult GetProductGroups([FromQuery] int? parentID, [FromQuery] bool ascending)
        {
            var productGroups = _productService.GetProductGroups(parentID, ascending);
            return Ok(productGroups);
        }

        [HttpGet]
        public IActionResult GetProducts(
            [FromQuery] string? sortBy,
            [FromQuery] bool? descending,
            [FromQuery] string? nameFilter,
            [FromQuery] string? groupNameFilter,
            [FromQuery] int? groupId,
            [FromQuery] bool? includeInactive)
        {
            var products = _productService.GetProducts(sortBy, descending, nameFilter, groupNameFilter, groupId, includeInactive);
            return Ok(products);
        }
    }
}
