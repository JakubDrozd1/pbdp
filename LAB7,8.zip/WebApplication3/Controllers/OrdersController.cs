﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace WebstoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost("{userId}/add-to-basket")]
        public IActionResult AddToBasket(int userId, [FromQuery] int productId, [FromQuery] int amount)
        {
            _orderService.AddToBasket(userId, productId, amount);
            return Ok("Item added to basket.");
        }

        [HttpPost("create/{userId}")]
        public IActionResult CreateOrder(int userId)
        {
            var orderResponse = _orderService.CreateOrder(userId);
            return Ok(orderResponse);
        }

        [HttpGet("{orderId}/positions")]
        public IActionResult GetOrderPositions(int orderId)
        {
            var orderPositions = _orderService.GetOrderPositions(orderId);
            return Ok(orderPositions);
        }

        [HttpGet]
        public IActionResult GetOrders([FromQuery] string? sortBy, [FromQuery] bool? descending, [FromQuery] int? orderId, [FromQuery] bool? isPaid)
        {
            var orders = _orderService.GetOrders(sortBy, descending, orderId, isPaid);
            return Ok(orders);
        }

        [HttpPost("pay/{orderId}")]
        public IActionResult PayOrder(int orderId, [FromBody] double amount)
        {
            _orderService.PayOrder(orderId, amount);
            return Ok("Order has been paid.");
        }

        [HttpDelete("{userId}/remove-from-basket/{productId}")]
        public IActionResult RemoveFromBasket(int userId, int productId)
        {
            _orderService.RemoveFromBasket(userId, productId);
            return Ok("Item removed from basket.");
        }

        [HttpPut("{userId}/update-basket-item/{productId}")]
        public IActionResult UpdateBasketItem(int userId, int productId, [FromBody] int amount)
        {
            _orderService.UpdateBasketItem(userId, productId, amount);
            return Ok("Basket item updated.");
        }
    }
}
