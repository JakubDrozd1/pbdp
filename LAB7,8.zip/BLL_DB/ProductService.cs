﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB
{
    public class ProductService(WebstoreContext _webstoreContext) : IProductService
    {
        public void ActivateProduct(int productId)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("ProductId", productId, DbType.Int32);

                connection.Execute(
                    "ActivateProduct",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
        }

        public void AddProduct(ProductRequestDTO productDto)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("Name", productDto.Name, DbType.String);
                parameters.Add("Price", productDto.Price, DbType.Decimal);
                parameters.Add("GroupID", productDto.GroupID, DbType.Int32);

                connection.Execute(
                    "AddProduct",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
        }

        public void AddProductGroup(ProductGroupRequestDTO productGroupDto)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("Name", productGroupDto.Name, DbType.String);
                parameters.Add("ParentID", productGroupDto.ParentID, DbType.Int32);

                connection.Execute(
                    "AddProductGroup",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
        }

        public void DeactivateProduct(int productId)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("ProductId", productId, DbType.Int32);

                connection.Execute(
                    "DeactivateProduct",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
        }

        public void DeleteProduct(int productId)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("ProductId", productId, DbType.Int32);

                connection.Execute(
                    "DeleteProduct",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );
            }
        }

        public IEnumerable<ProductGroupResponseDTO> GetProductGroups(int? parentID, bool ascending)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<ProductResponseDTO> GetProducts(
            string? sortBy,
            bool? descending,
            string? nameFilter,
            string? groupNameFilter,
            int? groupId,
            bool? includeInactive)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("SortBy", sortBy, DbType.String);
                parameters.Add("Descending", descending, DbType.Boolean);
                parameters.Add("NameFilter", nameFilter, DbType.String);
                parameters.Add("GroupNameFilter", groupNameFilter, DbType.String);
                parameters.Add("GroupId", groupId, DbType.Int32);
                parameters.Add("IncludeInactive", includeInactive, DbType.Boolean);

                var products = connection.Query<ProductResponseDTO>(
                    "GetProducts",
                    parameters,
                    commandType: CommandType.StoredProcedure
                ).ToList();

                return products;
            }
        }
    }
}
