﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB
{
    public class OrderService(WebstoreContext _webstoreContext): IOrderService
    {
        public void AddToBasket(int userID, int productID, int amount)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("UserID", userID);
                parameters.Add("ProductID", productID);
                parameters.Add("Amount", amount);

                connection.Execute("AddToBasket", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public int CreateOrder(int userId)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("UserID", userId);

                var orderId = connection.QuerySingle<int>("CreateOrder", parameters, commandType: CommandType.StoredProcedure);

                return orderId;
            }
        }

        public IEnumerable<OrderPositionResponseDTO> GetOrderPositions(int orderId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderResponseDTO> GetOrders(string? sortBy, bool? descending, int? orderId, bool? isPaid)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("SortBy", sortBy);
                parameters.Add("Descending", descending);
                parameters.Add("OrderID", orderId);
                parameters.Add("IsPaid", isPaid);

                var result = connection.Query<OrderResponseDTO>("GetOrders", parameters, commandType: CommandType.StoredProcedure);
                return result;
            }
        }

        public void PayOrder(int orderId, double amount)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("OrderID", orderId);
                parameters.Add("Amount", amount);

                connection.Execute("PayOrder", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public void RemoveFromBasket(int userId, int productId)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("UserID", userId);
                parameters.Add("ProductID", productId);

                connection.Execute("RemoveFromBasket", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public void UpdateBasketItem(int userId, int productId, int amount)
        {
            using (var connection = _webstoreContext.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("UserID", userId);
                parameters.Add("ProductID", productId);
                parameters.Add("Amount", amount);

                connection.Execute("UpdateBasketItem", parameters, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
