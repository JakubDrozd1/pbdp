﻿using BLL.DTOModels;

namespace BLL.ServiceInterfaces
{
    public interface IOrderService
    {
        void AddToBasket(int userId, int productId, int amount);
        void UpdateBasketItem(int userId, int productId, int amount);
        void RemoveFromBasket(int userId, int productId);
        int CreateOrder(int userId);
        void PayOrder(int orderId, double amount);
        IEnumerable<OrderResponseDTO> GetOrders(string? sortBy, bool? descending, int? orderId, bool? isPaid);
        IEnumerable<OrderPositionResponseDTO> GetOrderPositions(int orderId);
    }
}
