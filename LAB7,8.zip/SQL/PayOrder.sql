﻿CREATE PROCEDURE PayOrder
    @OrderID INT,
    @Amount DECIMAL(18, 2)  
AS
BEGIN
    DECLARE @TotalAmount DECIMAL(18, 2)  
    
    SELECT @TotalAmount = ISNULL(SUM(op.Amount * op.Price), 0)
    FROM OrderPositions op
    WHERE op.OrderID = @OrderID;

    IF NOT EXISTS (SELECT 1 FROM Orders WHERE ID = @OrderID AND IsPaid = 0)
    BEGIN
        RETURN;
    END
    IF @TotalAmount <> @Amount
    BEGIN
        RETURN;
    END
    
    UPDATE Orders
    SET IsPaid = 1
    WHERE ID = @OrderID;
END;
