﻿CREATE PROCEDURE AddProductGroup (@name VARCHAR(255), @parentId INT)
AS
BEGIN
    INSERT INTO ProductGroups (Name, ParentID)
    VALUES (@name, @parentId);
END
GO