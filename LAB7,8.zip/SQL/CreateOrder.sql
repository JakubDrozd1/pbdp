﻿CREATE PROCEDURE CreateOrder
    @UserID INT
AS
BEGIN
    DECLARE @OrderID INT;

    INSERT INTO Orders (UserID, Date)
    VALUES (@UserID, GETUTCDATE());
    SET @OrderID = SCOPE_IDENTITY();
    INSERT INTO OrderPositions (OrderID, ProductID, Amount, Price)
    SELECT @OrderID, bp.ProductID, bp.Amount, p.Price * bp.Amount
    FROM BasketPositions bp
    JOIN Products p ON p.ID = bp.ProductID
    WHERE bp.UserID = @UserID;
    SELECT @OrderID AS OrderID;
END;
