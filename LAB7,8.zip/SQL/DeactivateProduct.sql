﻿CREATE PROCEDURE DeactivateProduct (@productId INT)
AS
BEGIN
    UPDATE Products
    SET IsActive = 0
    WHERE ID = @productId;
END
GO

