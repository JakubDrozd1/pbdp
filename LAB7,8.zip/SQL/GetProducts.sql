﻿CREATE PROCEDURE GetProducts
@SortBy NVARCHAR(50) = NULL,
@Descending BIT = NULL,
@NameFilter NVARCHAR(255) = NULL,
@GroupNameFilter NVARCHAR(255) = NULL,
@GroupId INT = NULL,
@IncludeInactive BIT = NULL
AS
BEGIN
SET NOCOUNT ON;

WITH GroupHierarchy AS (
	SELECT g.ID, g.Name, g.ParentID, CAST(g.Name AS NVARCHAR(MAX)) AS Path
	FROM ProductGroups g WHERE g.ParentID IS NULL
	UNION ALL
	SELECT g.ID, g.Name, g.ParentID, CAST(pg.Path + '/' + g.Name AS NVARCHAR(MAX))
	FROM ProductGroups g
	INNER JOIN GroupHierarchy pg ON g.ParentID = pg.ID
)
SELECT
	p.ID,
	p.Name,
	p.Price,
	COALESCE(gh.Path, '') AS Path
FROM Products p
	LEFT JOIN GroupHierarchy gh ON p.GroupID = gh.ID
WHERE (@IncludeInactive = 1 OR p.IsActive = 1)
	AND (@NameFilter IS NULL OR p.Name LIKE '%' + @NameFilter + '%')
	AND (@GroupId IS NULL OR @GroupId < 0 OR p.GroupID IS NOT NULL)
	AND (@GroupNameFilter IS NULL OR gh.Path LIKE '%' + @GroupNameFilter + '%')
ORDER BY
	CASE WHEN @SortBy = 'Name' AND @Descending = 1 THEN p.Name END DESC,
	CASE WHEN @SortBy = 'Name' AND (@Descending IS NULL OR @Descending = 0) THEN p.Name END ASC,
	CASE WHEN @SortBy = 'Price' AND @Descending = 1 THEN p.Price END DESC,
	CASE WHEN @SortBy = 'Price' AND (@Descending IS NULL OR @Descending = 0) THEN p.Price END ASC,
	CASE WHEN @SortBy = 'GroupName' AND @Descending = 1 THEN gh.Path END DESC,
	CASE WHEN @SortBy = 'GroupName' AND (@Descending IS NULL OR @Descending = 0) THEN gh.Path END ASC;
END;