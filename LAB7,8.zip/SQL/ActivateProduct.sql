﻿CREATE PROCEDURE ActivateProduct (@productId INT)
AS
BEGIN
    UPDATE Products
    SET IsActive = 1
    WHERE ID = @productId;

END
GO
