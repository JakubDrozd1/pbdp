﻿CREATE PROCEDURE AddToBasket
    @UserID INT,
    @ProductID INT,
    @Amount INT
AS
BEGIN
    DECLARE @BasketItemExists INT;
    
    SELECT @BasketItemExists = COUNT(1)
    FROM BasketPositions
    WHERE UserID = @UserID AND ProductID = @ProductID;

    IF @BasketItemExists > 0
    BEGIN
        UPDATE BasketPositions
        SET Amount = Amount + @Amount
        WHERE UserID = @UserID AND ProductID = @ProductID;
    END
    ELSE
    BEGIN
        INSERT INTO BasketPositions (UserID, ProductID, Amount)
        VALUES (@UserID, @ProductID, @Amount);
    END
END;
