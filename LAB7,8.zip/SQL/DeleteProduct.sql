﻿CREATE PROCEDURE DeleteProduct (@productId INT)
AS
BEGIN
    DELETE FROM Products
    WHERE ID = @productId;
END
GO