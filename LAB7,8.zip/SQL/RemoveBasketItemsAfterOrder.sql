﻿CREATE TRIGGER RemoveBasketItemsAfterOrder
ON Orders
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM BasketPositions
    WHERE UserID IN (SELECT UserID FROM inserted);
END;
