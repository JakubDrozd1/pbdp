﻿CREATE PROCEDURE AddProduct
    @Name NVARCHAR(255),
    @Price DECIMAL(18,2),
    @GroupID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Products (Name, Price, GroupID, IsActive)
    VALUES (@Name, @Price, @GroupID, 1);
END;