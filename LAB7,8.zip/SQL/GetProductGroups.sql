﻿CREATE PROCEDURE GetProductGroups
    @ParentID INT = NULL,   
    @Ascending BIT = 1      
AS
BEGIN
    SELECT 
        pg.ID,
        pg.Name,
        CASE 
            WHEN EXISTS (SELECT 1 FROM ProductGroups WHERE ParentID = pg.ID) 
            THEN 1
            ELSE 0
        END AS HasChildren
    FROM ProductGroups pg
    WHERE (@ParentID IS NULL OR pg.ParentID = @ParentID)
    ORDER BY 
        CASE WHEN @Ascending = 1 THEN pg.Name END ASC,
        CASE WHEN @Ascending = 0 THEN pg.Name END DESC;
END
GO
