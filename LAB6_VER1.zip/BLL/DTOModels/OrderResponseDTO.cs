﻿namespace BLL.DTOModels
{
    public record OrderResponseDTO(int ID, double TotalValue, bool IsPaid, DateTime OrderDate);
}
