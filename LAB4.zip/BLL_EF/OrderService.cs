﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Model;

namespace BLL_EF
{
    internal class OrderService(WebstoreContext _webstoreContext) : IOrderService
    {
        private WebstoreContext webstoreContext = _webstoreContext;
        public void AddToBasket(int userId, int productId, int amount)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userId && bp.ProductID == productId);
            if (basketItem == null) return;
            basketItem.Amount += amount;
            webstoreContext.SaveChanges();

        }

        public OrderResponseDTO CreateOrder(int userId)
        {
            var order = new Order { UserID = userId, Date = DateTime.Now };
            webstoreContext.Orders.Add(order);
            webstoreContext.SaveChanges();
            return new OrderResponseDTO(order.ID, order.OrderPositions.Sum(op => op.Amount * op.Price), false, order.Date); ;
        }

        public IEnumerable<OrderPositionResponseDTO> GetOrderPositions(int orderId)
        {
            return webstoreContext.OrderPositions
                .Where(op => op.OrderID == orderId)
                .Select(op => new OrderPositionResponseDTO(op.Product.Name, op.Price, op.Amount, op.Amount * op.Price))
                .ToList();
        }

        public IEnumerable<OrderResponseDTO> GetOrders(string sortBy, bool descending, int? orderId, bool? isPaid)
        {
            var query = webstoreContext.Orders
                .Where(o => (!orderId.HasValue || o.ID == orderId) && (!isPaid.HasValue || o.IsPaid == isPaid))
                .Select(o => new OrderResponseDTO(o.ID, o.OrderPositions.Sum(op => op.Amount * op.Price),o.IsPaid, o.Date));

            switch (sortBy)
            {
                case "TotalValue":
                    query = descending ? query.OrderByDescending(o => o.TotalValue) : query.OrderBy(o => o.TotalValue);
                    break;
                case "Date":
                    query = descending ? query.OrderByDescending(o => o.OrderDate) : query.OrderBy(o => o.OrderDate);
                    break;
                case "IsPaid":
                    query = descending ? query.OrderByDescending(o => o.IsPaid) : query.OrderBy(o => o.IsPaid);
                    break;
                case "ID":
                    query = descending ? query.OrderByDescending(o => o.ID) : query.OrderBy(o => o.ID);
                    break;
                default:
                    query = descending ? query.OrderByDescending(o => o.ID) : query.OrderBy(o => o.ID);
                    break;
            }

            return query.ToList();
        }

        public void PayOrder(int orderId, double amount)
        {
            var order = webstoreContext.Orders.Find(orderId);
            if (order != null) order.IsPaid = true;
            webstoreContext.SaveChanges();
        }

        public void RemoveFromBasket(int userId, int productId)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userId && bp.ProductID == productId);
            if (basketItem == null) return;
            webstoreContext.BasketPositions.Remove(basketItem);
            webstoreContext.SaveChanges();
        }

        public void UpdateBasketItem(int userId, int productId, int amount)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userId && bp.ProductID == productId);
            if (basketItem == null) return;
            basketItem.Amount = amount;
            webstoreContext.SaveChanges();
        }
    }
}
