﻿namespace BLL.DTOModels
{
    public record OrderPositionResponseDTO(string ProductName, double Price, int Amount, double TotalValue);

}