﻿using Bogus;
using Microsoft.EntityFrameworkCore;
using Model;
using Model.Enum;
using DAL;

using (var context = new WebstoreContext())
{
    context.Database.EnsureCreated();

    var fakeUserGroups = new Faker<UserGroup>()
        .RuleFor(g => g.Name, f => f.Company.CompanyName())
        .Generate(5);

    var fakeProductGroups = new Faker<ProductGroup>()
        .RuleFor(pg => pg.Name, f => f.Commerce.Department())
        .Generate(5);

    context.UserGroups.AddRange(fakeUserGroups);
    context.ProductGroups.AddRange(fakeProductGroups);
    context.SaveChanges();

    var productFaker = new Faker<Product>()
        .RuleFor(p => p.Name, f => f.Commerce.ProductName())
        .RuleFor(p => p.Price, f => f.Random.Double(10, 500))
        .RuleFor(p => p.Image, f => f.Internet.Avatar())
        .RuleFor(p => p.IsActive, f => f.Random.Bool())
        .RuleFor(p => p.GroupID, f => f.PickRandom(fakeProductGroups).ID);

    var fakeProducts = productFaker.Generate(20);
    context.Products.AddRange(fakeProducts);
    context.SaveChanges();

    var userFaker = new Faker<User>()
        .RuleFor(u => u.Login, f => f.Internet.UserName())
        .RuleFor(u => u.Password, f => f.Internet.Password(8))
        .RuleFor(u => u.Type, f => f.PickRandom<UserType>())
        .RuleFor(u => u.IsActive, f => f.Random.Bool())
        .RuleFor(u => u.GroupID, f => f.PickRandom(fakeUserGroups).ID);

    var fakeUsers = userFaker.Generate(5);
    context.Users.AddRange(fakeUsers);
    context.SaveChanges();

    var orderFaker = new Faker<Order>()
        .RuleFor(o => o.Date, f => f.Date.Past(2))
        .RuleFor(o => o.IsPaid, f => f.Random.Bool())
        .RuleFor(o => o.UserID, f => f.PickRandom(fakeUsers).ID);

    var fakeOrders = orderFaker.Generate(10);
    context.Orders.AddRange(fakeOrders);
    context.SaveChanges();

    var orderPositions = new List<OrderPosition>();
    var random = new Random();

    foreach (var order in fakeOrders)
    {
        var productSubset = fakeProducts.OrderBy(x => random.Next()).Take(random.Next(1, 5)).ToList();

        foreach (var product in productSubset)
        {
            if (!orderPositions.Any(op => op.OrderID == order.ID && op.ProductID == product.ID))
            {
                orderPositions.Add(new OrderPosition
                {
                    OrderID = order.ID,
                    ProductID = product.ID,
                    Amount = random.Next(1, 3),
                    Price = product.Price
                });
            }
        }
    }

    context.OrderPositions.AddRange(orderPositions);
    context.SaveChanges();

    var basketPositions = new List<BasketPosition>();

    foreach (var user in fakeUsers)
    {
        var productSubset = fakeProducts.OrderBy(x => random.Next()).Take(random.Next(1, 5)).ToList();

        foreach (var product in productSubset)
        {
            if (!basketPositions.Any(bp => bp.UserID == user.ID && bp.ProductID == product.ID))
            {
                basketPositions.Add(new BasketPosition
                {
                    UserID = user.ID,
                    ProductID = product.ID,
                    Amount = random.Next(1, 3)
                });
            }
        }
    }

    context.BasketPositions.AddRange(basketPositions);
    context.SaveChanges();
}

using (var context = new WebstoreContext())
{
    var users = context.Users
        .Include(u => u.Group)
        .Include(u => u.Orders)
        .ThenInclude(o => o.OrderPositions)
        .ThenInclude(op => op.Product)
        .Include(u => u.BasketPositions)
        .ThenInclude(bp => bp.Product)
        .ToList();

    foreach (var user in users)
    {
        Console.WriteLine($"User: {user.Login}, {user.Type}, Active: {user.IsActive}");
        Console.WriteLine($"  Group: {user.Group?.Name}");
        Console.WriteLine($"  Orders: {user.Orders.Count}, Basket Items: {user.BasketPositions.Count}");

        foreach (var order in user.Orders)
        {
            Console.WriteLine($"    Order {order.ID}: {order.Date}, Paid: {order.IsPaid}");
            foreach (var orderPos in order.OrderPositions)
            {
                Console.WriteLine($"      Product: {orderPos.Product.Name}, Amount: {orderPos.Amount}, Price: {orderPos.Price:C}");
            }
        }

        foreach (var basket in user.BasketPositions)
        {
            Console.WriteLine($"    Basket Item: {basket.Product.Name}, Amount: {basket.Amount}");
        }
        Console.WriteLine();
    }
}
