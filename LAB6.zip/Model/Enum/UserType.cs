﻿namespace Model.Enum
{
    public enum UserType
    {
        Admin,
        Casual
    }
}
