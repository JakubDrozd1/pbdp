﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Model;

namespace BLL_EF
{
    public class UserService(WebstoreContext _webstoreContext) : IUserService
    {
        private WebstoreContext webstoreContext = _webstoreContext;
        private static User? loggedUser;
        public int Login(UserRequestDTO userDto)
        {
            var user = webstoreContext.Users.FirstOrDefault(u => u.Login == userDto.Login && u.Password == userDto.Password);
            if (user == null) return 0;
            loggedUser = user;
            return user.ID;
        }

        public void Logout()
        {
            loggedUser = null;
        }
    }
}
