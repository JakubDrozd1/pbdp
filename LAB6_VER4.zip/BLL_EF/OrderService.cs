﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Microsoft.EntityFrameworkCore;
using Model;

namespace BLL_EF
{
    public class OrderService(WebstoreContext _webstoreContext) : IOrderService
    {
        private WebstoreContext webstoreContext = _webstoreContext;
        public void AddToBasket(int userID, int productID, int amount)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userID && bp.ProductID == productID);
            if (basketItem != null)
                basketItem.Amount += amount;
            else
                webstoreContext.BasketPositions.Add(new BasketPosition { UserID = userID, ProductID = productID, Amount = amount });

            webstoreContext.SaveChanges();
        }

        public int CreateOrder(int userId)
        {
            var basketItems = webstoreContext.BasketPositions.Where(bp => bp.UserID == userId).ToList();

            var order = new Order { UserID = userId, Date = DateTime.UtcNow };
            webstoreContext.Orders.Add(order);
            webstoreContext.SaveChanges();

            foreach (var item in basketItems)
            {
                var product = webstoreContext.Products.Find(item.ProductID);
                webstoreContext.OrderPositions.Add(new OrderPosition { OrderID = order.ID, ProductID = item.ProductID, Amount = item.Amount, Price = product.Price * item.Amount });
            }

            webstoreContext.BasketPositions.RemoveRange(basketItems);
            webstoreContext.SaveChanges();
            return order.ID;
        }



        public IEnumerable<OrderPositionResponseDTO> GetOrderPositions(int orderId)
        {
            return webstoreContext.OrderPositions
                .Where(op => op.OrderID == orderId)
                .Select(op => new OrderPositionResponseDTO(op.Product.Name, op.Price, op.Amount, op.Amount * op.Price))
                .ToList();
        }

        public IEnumerable<OrderResponseDTO> GetOrders(string? sortBy, bool? descending, int? orderId, bool? isPaid)
        {
            var query = webstoreContext.Orders
                .Where(o => (!orderId.HasValue || o.ID == orderId) && (!isPaid.HasValue || o.IsPaid == isPaid))
                .ToList()
                .Select(o => new OrderResponseDTO(
                    o.ID,
                    webstoreContext.OrderPositions
                        .Where(o0 => o0.OrderID == o.ID)
                        .Sum(o0 => (double)o0.Amount * o0.Price),
                    o.IsPaid,
                    o.Date
                ));

            switch (sortBy)
            {
                case "TotalValue":
                    query = descending ?? false ? query.OrderByDescending(o => o.TotalValue) : query.OrderBy(o => o.TotalValue);
                    break;
                case "Date":
                    query = descending ?? false ? query.OrderByDescending(o => o.OrderDate) : query.OrderBy(o => o.OrderDate);
                    break;
                case "IsPaid":
                    query = descending ?? false ? query.OrderByDescending(o => o.IsPaid) : query.OrderBy(o => o.IsPaid);
                    break;
                case "ID":
                    query = descending ?? false ? query.OrderByDescending(o => o.ID) : query.OrderBy(o => o.ID);
                    break;
                default:
                    query = descending ?? false ? query.OrderByDescending(o => o.ID) : query.OrderBy(o => o.ID);
                    break;
            }

            return query.ToList();
        }

        public void PayOrder(int orderId, double amount)
        {
            var order = webstoreContext.Orders
                .Include(o => o.OrderPositions)
                .FirstOrDefault(o => o.ID == orderId);

            if (order == null) return;
            if (order.IsPaid) throw new Exception("is paid");

            if (order.OrderPositions == null || !order.OrderPositions.Any())
                throw new Exception("Order has no positions");

            if (order.OrderPositions.Sum(op => op.Amount * op.Price) != amount) return;

            order.IsPaid = true;
            webstoreContext.SaveChanges();
        }

        public void RemoveFromBasket(int userId, int productId)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userId && bp.ProductID == productId);
            if (basketItem == null) return;
            webstoreContext.BasketPositions.Remove(basketItem);
            webstoreContext.SaveChanges();
        }

        public void UpdateBasketItem(int userId, int productId, int amount)
        {
            var basketItem = webstoreContext.BasketPositions.FirstOrDefault(bp => bp.UserID == userId && bp.ProductID == productId);
            if (basketItem == null) return;
            basketItem.Amount = amount;
            webstoreContext.SaveChanges();
        }
    }
}