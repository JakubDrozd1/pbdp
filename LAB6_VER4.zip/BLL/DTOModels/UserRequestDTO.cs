﻿namespace BLL.DTOModels
{
    public record UserRequestDTO(string Login, string Password);

}
