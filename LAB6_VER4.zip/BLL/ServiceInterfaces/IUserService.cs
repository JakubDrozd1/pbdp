﻿using BLL.DTOModels;

namespace BLL.ServiceInterfaces
{
    public interface IUserService
    {
        int Login(UserRequestDTO userDto);
        void Logout();
    }
}
